// Base de datos configuracion local
module.exports =
{
    DATABASE: 'delilah-resto',
    DIALECT: 'mysql',
    HOST: 'localhost',
    PASSWORD: null,
    PORT: 3306,
    TIMEZONE: '-05:00', // Hora local para la base de datos
    USERNAME: 'root'
}